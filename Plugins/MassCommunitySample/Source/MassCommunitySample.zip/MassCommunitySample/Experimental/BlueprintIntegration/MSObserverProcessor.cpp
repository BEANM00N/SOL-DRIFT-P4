// Fill out your copyright notice in the Description page of Project Settings.


#include "MSObserverProcessor.h"
#include "MassCommonFragments.h"
#include "MassExecutionContext.h"

#include "MassObserverRegistry.h"
#include "Common/Misc/MSBPFunctionLibrary.h"

#include UE_INLINE_GENERATED_CPP_BY_NAME(MSObserverProcessor)

UMSObserverProcessorBP::UMSObserverProcessorBP()
{
	bAutoRegisterWithProcessingPhases = false;
	bRequiresGameThreadExecution = true;
	ExecutionFlags = (int32)(EProcessorExecutionFlags::Server | EProcessorExecutionFlags::Standalone | EProcessorExecutionFlags::Editor);
	
}


void UMSObserverProcessorBP::ConfigureQueries(const TSharedRef<FMassEntityManager>& EntityManager)
{
	EntityQuery.Initialize(EntityManager);

	for (auto Fragment : FragmentRequirements)
	{
		if(Fragment.IsValid())
		EntityQuery.AddRequirement(Fragment.GetScriptStruct(),EMassFragmentAccess::ReadWrite);
	}
	for (auto Tag : TagRequirements)
	{
		if(Tag.IsValid())
		EntityQuery.AddTagRequirement(*Tag.GetScriptStruct(),EMassFragmentPresence::All);
	}
	EntityQuery.RegisterWithProcessor(*this);

}



void UMSObserverProcessorBP::Execute(FMassEntityManager& EntityManager, FMassExecutionContext& Context)
{

	TArray<const UScriptStruct*> ReuiredAllFragmentTypes;
	EntityQuery.GetRequiredAllFragments().ExportTypes(ReuiredAllFragmentTypes);
	auto World = GetWorld();

	EntityQuery.ForEachEntityChunk( Context, [&](FMassExecutionContext& Context)
	{
		TArray<TArrayView<FMassFragment>> FragmentViews;
		for (auto Fragment : ReuiredAllFragmentTypes )
		{
			FragmentViews.Add(Context.GetMutableFragmentView(Fragment));
		}
		
		const int32 QueryLength = Context.GetNumEntities();

		// Surely there is a less wacky way to get an archetype inside of a context? This is definitely weird.
		FMassArchetypeHandle Archetype = EntityManager.GetArchetypeForEntityUnsafe(Context.GetEntity(0));

		for (int32 i = 0; i < QueryLength; ++i)
		{
			for ([[maybe_unused]] auto FragmentView : FragmentViews)
			{
				// snipped for now, might not bother with these
			}
			BPExecute(FMSEntityViewBPWrapper(Archetype,Context.GetEntity(i)), World);

		}
	});
}


